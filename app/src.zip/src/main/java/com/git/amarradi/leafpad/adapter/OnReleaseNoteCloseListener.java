package com.git.amarradi.leafpad.adapter;

public interface OnReleaseNoteCloseListener {
    void onReleaseNoteClosed();
}
