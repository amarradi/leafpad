package com.git.amarradi.leafpad.model;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.HashSet;
import java.util.Set;

@Database(
        entities = {
                Category.class
                // Note-Entity fügen wir später dazu, wenn wir Notizen migrieren
        },
        version = 2,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract CategoryDao categoryDao();
    public abstract NoteDao noteDao();


    private static Context appContext;

    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase db) {

            // 1) Notes-Tabelle erzeugen
            db.execSQL(
                    "CREATE TABLE IF NOT EXISTS notes (" +
                            "id TEXT PRIMARY KEY NOT NULL, " +
                            "title TEXT, " +
                            "body TEXT, " +
                            "date TEXT, " +
                            "time TEXT, " +
                            "createDate TEXT, " +
                            "hide INTEGER NOT NULL, " +
                            "category_key TEXT)"
            );

            // 2) SharedPrefs-Daten migrieren
            migrateNotesFromSharedPrefs(appContext, db);
        }
    };

    private static void migrateNotesFromSharedPrefs(Context context, SupportSQLiteDatabase db) {
        SharedPreferences prefs = context.getSharedPreferences("leafstore", Context.MODE_PRIVATE);
        Set<String> ids = prefs.getStringSet("note_id_set", new HashSet<>());

        for (String id : ids) {
            String title = prefs.getString("note_title_" + id, "");
            String body = prefs.getString("note_body_" + id, "");
            String date = prefs.getString("note_date_set" + id, "");
            String time = prefs.getString("note_time_set" + id, "");
            String createDate = prefs.getString("note_date_" + id, "");
            boolean hide = prefs.getBoolean("hide_" + id, false);

            String cat = prefs.getString("note_category_" + id, "");

            if ("Rezept".equals(cat)) cat = "recipe";

            db.execSQL(
                    "INSERT OR REPLACE INTO notes (id, title, body, date, time, createDate, hide, category_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    new Object[]{ id, title, body, date, time, createDate, hide ? 1 : 0, cat }
            );
        }
    }



    // Callback, der NUR beim ersten Erzeugen der Datenbank aufgerufen wird
    private static final RoomDatabase.Callback PREPOPULATE_CALLBACK =
            new RoomDatabase.Callback() {
                @Override
                public void onCreate(@NonNull SupportSQLiteDatabase db) {
                    super.onCreate(db);

                    long now = System.currentTimeMillis();

                    // id wird automatisch generiert, deshalb nicht angeben
                    db.execSQL(
                            "INSERT INTO categories " +
                                    "(name, color_hex, sort_order, is_archived, created_at, updated_at) " +
                                    "VALUES (" +
                                    "'Rezept'," +          // name
                                    "'#000080'," +             // color_hex
                                    "0," +                // sort_order
                                    "0," +                // is_archived (0 = aktiv)
                                    now + "," +           // created_at (ms)
                                    now +                 // updated_at (ms)
                                    ")"
                    );
                }
            };

    public static AppDatabase getInstance(Context context) {
        appContext = context.getApplicationContext();

        INSTANCE = Room.databaseBuilder(appContext, AppDatabase.class, "leafpad.db")
                .addMigrations(MIGRATION_1_2)
                .build();

        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "leafpad.db"
                            )
                            .addCallback(PREPOPULATE_CALLBACK) // <-- hier kommt das Seeding dazu
                            .fallbackToDestructiveMigrationOnDowngrade()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
