package com.git.amarradi.leafpad.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "notes",
        foreignKeys = @ForeignKey(
                entity = Category.class,
                parentColumns = "key",
                childColumns = "category_key",
                onDelete = ForeignKey.SET_NULL
        )
)
public class NoteEntity {

    @PrimaryKey
    @NonNull
    public String id;

    public String title;
    public String body;
    public String date;
    public String time;
    public String createDate;

    @ColumnInfo(name = "hide")
    public boolean hide;

    @ColumnInfo(name = "category_key")
    public String categoryKey; // z.B. "recipe"
}
